import React, { Component } from "react";
import Logo from "./components/Logo";
import Characters from "./components/Characters";
import Selection from "./components/Selections";
import "./App.css";
import start from "./images/start.gif";
import stopStart from "./images/stopStart.gif";
import started from "./images/started.gif";
const axios = require("axios");
var remote = window.require("electron").remote;

class App extends Component {
  constructor(props) {
    super(props);
    this.selectsRef = React.createRef();
    this.accountsRef = React.createRef();
    this.state = {
      status: 1,
      showPopup: false,
    };
  }

  render() {
    return (
      <div>
        <Logo />
        <div id="menu">
          <Characters ref={this.accountsRef} />
          <Selection ref={this.selectsRef} />
          <div
            id="start"
            onClick={() => {
              const mode = this.selectsRef.current.state["selection"];
              const select = "selected" + mode[0].toUpperCase() + mode.slice(1);
              return axios
                .post("http://127.0.0.1:5000/bot_api/selected_data", {
                  accounts: this.accountsRef.current.state["accounts"],
                  mode: mode,
                  selects: this.selectsRef.current.state[select],
                })
                .then((response) => {
                  console.log(response);
                  if (response["data"] !== "OK") {
                    alert(response.data);
                  }
                });
            }}
          >
            <img
              className="startbuttom"
              src={stopStart}
              onMouseOver={(event) => {
                event.currentTarget.src = start;
              }}
              onMouseOut={(event) => {
                event.currentTarget.src = stopStart;
              }}
              onClick={(event) => {
                event.currentTarget.src = started;
              }}
              width="150px"
              height="150px"
            />
          </div>
        </div>
      </div>
    );
  }
}

export default App;
