import React, { Component } from "react";
import "./Characters.css";
import plus from "../images/plus.png";
import trash from "../images/trash2.png";

class Characters extends Component {
  constructor(props) {
    super(props);
    this.state = {
      accounts: [
        { status: "empty" },
        { status: "empty" },
        { status: "empty" },
        { status: "empty" },
        { status: "empty" },
        { status: "empty" },
        { status: "empty" },
        { status: "empty" },
      ],
    };
  }

  render() {
    return (
      <div className="characterBox">
        <h1 id="titleCharacterBox">ACCOUNTS</h1>
        <div className="insideCharacterBox">
          {this.state.accounts.map((item, index) =>
            this.renderCardContent(item, index)
          )}
        </div>
      </div>
    );
  }

  componentDidUpdate() {
    console.log("CDU");
  }

  changeStatusCard(index, status) {
    console.log("CHANGE SATTSUAS", index);
    const accounts = this.state.accounts;
    accounts[index].status = status;
    this.setState({ accounts });
  }

  renderCardContent(item, index) {
    if (item.status === "empty")
      return (
        <div
          key={index}
          className="card"
          onClick={() => this.changeStatusCard(index, "adding")}
        >
          <img src={plus} id="addImage" />
        </div>
      );
    if (item.status === "adding")
      return (
        <div key={index} className="addingPlayer">
          {this.renderForm(index)}
        </div>
      );
  }

  renderForm(index) {
    return (
      <form>
        <label>
          <h1 className="formHead">Login</h1>
          <input
            className="input"
            type="text"
            value={this.state.accounts[index].login}
            onChange={(event) => this.onChangeinput(event, "login", index)}
          />
          <h1 className="formHead">Password</h1>
          <input
            className="input"
            type="text"
            value={this.state.accounts[index].password}
            onChange={(event) => this.onChangeinput(event, "password", index)}
          />
          <h1 className="formHead">Character Name</h1>
          <input
            className="input"
            type="text"
            value={this.state.accounts[index].name}
            onChange={(event) => this.onChangeinput(event, "name", index)}
          />
          <div
            className="delButton"
            onClick={(event) => this.deleteForm(event, index)}
          >
            <img src={trash} width="100%" />
          </div>
        </label>
      </form>
    );
  }

  deleteForm(event, index) {
    this.changeStatusCard(index, "empty");
    event.stopPropagation();
    const accounts = this.state.accounts;
    accounts[index] = { status: "empty" };
    this.setState({ accounts });
  }

  onChangeinput(event, field, index) {
    console.log(event.target.value, index);
    const accounts = this.state.accounts;
    accounts[index][field] = event.target.value;
    this.setState({ accounts });
  }
}

export default Characters;
